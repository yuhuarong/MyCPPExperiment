#pragma once
#include <iostream>
using namespace std;

class Shape {
public:
	virtual float area() const {return 0.0;};
	virtual float volume() const {return 0.0;}
	virtual void shapeName() const = 0;
};